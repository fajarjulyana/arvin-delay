These files are DCT files (Dib Component Templates)

Each file is placed in a folder named after the type of component it applies to.
However, these templates are interchangeable, you can load a DIBDial component template
into a DIBSlider component for example (although, it may look a little odd).

If you have designed component templates, please share them with the rest of the World.
Send them along to me at dib@stuckindoors.com so that I can include them on the site !

Instructions for use.

Drop a DIBContainer on your form.
Drop a DIBImageList on your form.
Drop a TDIBxxxxxxxx component (Slider, etc) on your form, and point the DIBImageList to DIBImageList1
Right-click your component and select "Load template"


Pete